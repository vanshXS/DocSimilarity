import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getResults, checkSessionStatus } from "../api/analysisApi"; // Import checkSessionStatus
import { FileText, ArrowRight, Loader2, AlertCircle, ArrowLeft, Calendar } from "lucide-react";

export default function Results() {
  const navigate = useNavigate();
  const { sessionId } = useParams();
  
  const [results, setResults] = useState([]);
  const [sessionInfo, setSessionInfo] = useState({ subject: "", title: "", date: "" }); // Store Name
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (sessionId) {
      loadData(sessionId);
    } else {
      setError("Invalid Session ID.");
      setLoading(false);
    }
  }, [sessionId]);

  const loadData = async (id) => {
    try {
      // 1. Fetch Session Info (Name, Date)
      const info = await checkSessionStatus(id);
      setSessionInfo({
        subject: info.subject,
        title: info.title,
        date: new Date(info.created_at).toLocaleDateString()
      });

      // 2. Fetch Results
      const data = await getResults(id);
      const sortedResults = (data.results || []).sort(
        (a, b) => b.similarity_percentage - a.similarity_percentage
      );
      setResults(sortedResults);

    } catch (err) {
      console.error("Failed to load data", err);
      setError("Failed to load analysis results.");
    } finally {
      setLoading(false);
    }
  };

  const handleViewDetails = (item) => {
    navigate(`/comparison/${item.result_id}`, {
      state: {
        resultId: item.result_id,
        fileA: item.file_a,
        fileB: item.file_b,
        overallScore: item.similarity_percentage,
        sessionId: sessionId 
      },
    });
  };

  const getScoreColor = (score) => {
    if (score >= 70) return "text-red-700 bg-red-50 border-red-200";
    if (score >= 40) return "text-orange-700 bg-orange-50 border-orange-200";
    return "text-green-700 bg-green-50 border-green-200";
  };

  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto py-8 px-4">
      {/* Back Button */}
      <button
        onClick={() => navigate("/")}
        className="flex items-center gap-2 text-gray-500 hover:text-gray-900 mb-6 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Dashboard
      </button>

      {/* Header with Session Name */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h1 className="text-3xl font-bold text-gray-900">
              {sessionInfo.subject || "Analysis Results"}
            </h1>
            <span className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded font-mono">
              {sessionId?.slice(0, 8)}
            </span>
          </div>
          <div className="flex items-center gap-4 text-gray-500 text-sm">
            {sessionInfo.title && <span>{sessionInfo.title}</span>}
            <span className="flex items-center gap-1">
               <Calendar className="w-3.5 h-3.5" /> {sessionInfo.date}
            </span>
          </div>
        </div>
        
        <button
          onClick={() => navigate("/upload")}
          className="px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors shadow-sm"
        >
          New Analysis
        </button>
      </div>

      {error ? (
        <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-center text-red-700">
          <AlertCircle className="w-8 h-8 mx-auto mb-2" />
          <p>{error}</p>
        </div>
      ) : results.length === 0 ? (
        <div className="text-center p-12 bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="bg-gray-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <FileText className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900">No Similarities Found</h3>
          <p className="text-gray-500 mt-2">
            Great news! No significant similarities were detected in this session.
          </p>
        </div>
      ) : (
        <div className="grid gap-4">
          {results.map((item) => (
            <div
              key={item.result_id}
              className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md hover:border-indigo-200 transition-all group"
            >
              <div className="flex items-center justify-between">
                
                {/* Comparison Info */}
                <div className="flex items-center gap-6 flex-1">
                  <div className="flex items-center gap-3 min-w-[200px]">
                    <div className="p-2 bg-indigo-50 rounded-lg group-hover:bg-indigo-100 transition-colors">
                      <FileText className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 truncate max-w-[180px]">{item.file_a.filename}</p>
                      <p className="text-xs text-gray-400">Document A</p>
                    </div>
                  </div>

                  <div className="flex flex-col items-center px-4">
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-1">VS</span>
                    <ArrowRight className="w-4 h-4 text-gray-300 group-hover:text-indigo-400 transition-colors" />
                  </div>

                  <div className="flex items-center gap-3 justify-end text-right min-w-[200px]">
                    <div>
                      <p className="font-semibold text-gray-900 truncate max-w-[180px]">{item.file_b.filename}</p>
                      <p className="text-xs text-gray-400">Document B</p>
                    </div>
                    <div className="p-2 bg-purple-50 rounded-lg group-hover:bg-purple-100 transition-colors">
                      <FileText className="w-5 h-5 text-purple-600" />
                    </div>
                  </div>
                </div>

                {/* Score & Action */}
                <div className="ml-12 flex items-center gap-6 border-l pl-8 border-gray-100">
                  <div className="text-center">
                    <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold border ${getScoreColor(item.similarity_percentage)}`}>
                      {item.similarity_percentage}% Match
                    </span>
                  </div>
                  
                  <button
                    onClick={() => handleViewDetails(item)}
                    className="px-5 py-2.5 bg-gray-900 text-white text-sm font-medium rounded-lg hover:bg-indigo-600 shadow-sm hover:shadow transition-all"
                  >
                    View Report
                  </button>
                </div>

              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}