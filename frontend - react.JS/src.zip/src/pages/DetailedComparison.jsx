import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ArrowLeft, AlertCircle, Loader2 } from "lucide-react";
import { getHighlights, getSectionResults } from "../api/analysisApi";

export default function DetailedComparison() {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Get sessionId from state so we know where to go back to
  const { fileA, fileB, overallScore, sessionId } = location.state || {};

  const [loading, setLoading] = useState(true);
  const [sections, setSections] = useState([]);
  const [highlights, setHighlights] = useState([]);

  useEffect(() => {
    if (!fileA || !fileB) {
      navigate("/");
      return;
    }
    fetchDetails();
  }, []);

  const fetchDetails = async () => {
    try {
      // Use the session ID passed from the previous page, or fall back to localStorage if lost
      const currentSessionId = sessionId || localStorage.getItem("current_session_id");
      
      const secRes = await getSectionResults(currentSessionId);
      const relevantSections = (secRes.section_results || []).filter(
        s => (s.file_a_id === fileA.file_id && s.file_b_id === fileB.file_id) ||
             (s.file_a_id === fileB.file_id && s.file_b_id === fileA.file_id)
      ).sort((a,b) => a.section_index - b.section_index);

      setSections(relevantSections);

      const hlRes = await getHighlights(currentSessionId, fileA.file_id, fileB.file_id);
      setHighlights(hlRes.highlights || []);

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    if (sessionId) {
      navigate(`/session/${sessionId}`);
    } else {
      navigate("/");
    }
  };

  const getStatusColor = (score) => score >= 70 ? "bg-red-100 text-red-800" : score >= 40 ? "bg-orange-100 text-orange-800" : "bg-green-100 text-green-800";
  const getStatusLabel = (score) => score >= 70 ? "High" : score >= 40 ? "Medium" : "Low";
  const getProgressBarColor = (score) => score >= 70 ? "bg-red-500" : score >= 40 ? "bg-orange-500" : "bg-green-500";

  if (loading) return <div className="flex h-full items-center justify-center"><Loader2 className="animate-spin w-8 h-8 text-indigo-600"/></div>;

  return (
    <div className="max-w-5xl mx-auto py-8">
      <button onClick={handleBack} className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors">
        <ArrowLeft className="w-5 h-5" />
        Back to Results
      </button>

      <div className="mb-8">
        <h1 className="text-3xl font-semibold text-gray-900">Detailed Report</h1>
        <p className="text-gray-600 mt-2">
          Comparing <span className="font-medium text-indigo-600">{fileA.filename}</span> vs <span className="font-medium text-indigo-600">{fileB.filename}</span>
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-8 mb-8 border border-gray-200">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Overall Similarity</h2>
          <span className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${getStatusColor(overallScore)}`}>
            <AlertCircle className="w-4 h-4" /> {getStatusLabel(overallScore)}
          </span>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex-1 h-4 bg-gray-100 rounded-full overflow-hidden">
            <div className={`h-full rounded-full transition-all duration-1000 ${getProgressBarColor(overallScore)}`} style={{ width: `${overallScore}%` }}></div>
          </div>
          <p className="text-4xl font-semibold text-gray-900">{overallScore}%</p>
        </div>
      </div>

      {sections.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8 border border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Section Breakdown</h2>
          <div className="space-y-6">
            {sections.map((sec, index) => (
              <div key={index} className="border-b border-gray-100 pb-6 last:border-b-0 last:pb-0 flex items-center justify-between">
                <h3 className="font-medium text-gray-900">Section {sec.section_index}</h3>
                <div className="flex items-center gap-4 flex-1 max-w-sm">
                  <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${getProgressBarColor(sec.similarity_percentage)}`} style={{ width: `${sec.similarity_percentage}%` }}></div>
                  </div>
                  <span className="font-medium text-gray-900 w-12 text-right">{sec.similarity_percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-200">
        <div className="flex items-start gap-3 mb-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-amber-900">Detected Similar Content</h3>
            <p className="text-sm text-amber-700 mt-1">Direct sentence matches found in both documents.</p>
          </div>
        </div>

        <div className="space-y-6">
          {highlights.length === 0 ? (
             <p className="text-gray-500 italic text-center py-4">No direct sentence matches found.</p>
          ) : (
            highlights.map((match, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                 <div className="flex justify-between items-center mb-3">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Match #{index + 1}</span>
                    <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded font-bold">{match.similarity}%</span>
                 </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div className="bg-gray-50 p-3 rounded border border-gray-200">
                      <p className="text-xs text-gray-500 mb-1 font-semibold">{fileA.filename}</p>
                      <p className="text-sm text-gray-800 leading-relaxed bg-yellow-200/50 p-1 rounded inline">{match.sentence_a}</p>
                   </div>
                   <div className="bg-gray-50 p-3 rounded border border-gray-200">
                      <p className="text-xs text-gray-500 mb-1 font-semibold">{fileB.filename}</p>
                       <p className="text-sm text-gray-800 leading-relaxed bg-yellow-200/50 p-1 rounded inline">{match.sentence_b}</p>
                   </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}