import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getDashboardStats } from "../api/analysisApi";
import { BarChart3, Files, AlertTriangle, Percent, ArrowRight, Loader2, Plus } from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const [stats, setStats] = useState({ total_sessions: 0, total_documents: 0, high_risk_cases: 0, average_similarity: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const data = await getDashboardStats();
        setStats(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }
    loadStats();
  }, []);

  if (loading) return <div className="flex h-screen items-center justify-center"><Loader2 className="animate-spin text-indigo-600 w-10 h-10" /></div>;

  return (
    <div className="max-w-6xl mx-auto py-8 px-4">
      {/* Header with Action Buttons */}
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500 mt-1">System overview and analytics.</p>
        </div>
        <div className="flex gap-3">
           <button 
            onClick={() => navigate("/upload")} 
            className="flex items-center gap-2 bg-white border border-gray-300 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-50 transition-colors"
          >
            <Plus className="w-4 h-4" /> New Analysis
          </button>
          <button 
            onClick={() => navigate("/results")} 
            className="flex items-center gap-2 bg-indigo-600 text-white px-5 py-2 rounded-lg font-medium hover:bg-indigo-700 shadow-sm transition-colors"
          >
            View All Results <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Assignments" value={stats.total_sessions} icon={<BarChart3 className="text-indigo-600 w-6 h-6" />} bg="bg-indigo-50" />
        <StatCard title="Documents Processed" value={stats.total_documents} icon={<Files className="text-blue-600 w-6 h-6" />} bg="bg-blue-50" />
        <StatCard title="High Risk Cases" value={stats.high_risk_cases} icon={<AlertTriangle className="text-red-600 w-6 h-6" />} bg="bg-red-50" color="text-red-600" />
        <StatCard title="Avg. Similarity" value={`${stats.average_similarity}%`} icon={<Percent className="text-emerald-600 w-6 h-6" />} bg="bg-emerald-50" color="text-emerald-600" />
      </div>

      {/* Empty State / Call to Action area could go here */}
      <div className="mt-12 bg-gray-50 rounded-2xl p-8 text-center border border-gray-100">
         <h3 className="text-lg font-semibold text-gray-900">Ready to analyze?</h3>
         <p className="text-gray-500 mt-2 mb-6">Upload new assignments to check for plagiarism and similarity.</p>
         <button onClick={() => navigate("/upload")} className="text-indigo-600 font-semibold hover:underline">Start New Analysis</button>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, bg, color = "text-gray-900" }) {
  return (
    <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
      <div className={`p-4 rounded-xl ${bg}`}>{icon}</div>
      <div>
        <p className="text-sm font-medium text-gray-500">{title}</p>
        <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
      </div>
    </div>
  );
}