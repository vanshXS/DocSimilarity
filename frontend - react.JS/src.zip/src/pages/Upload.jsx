import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Upload as UploadIcon, FileText, CheckCircle, Loader2, X, AlertCircle } from "lucide-react";
import { createSession, uploadFiles, triggerAutoProcess, checkSessionStatus } from "../api/analysisApi";

export default function Upload() {
  const navigate = useNavigate();
  const [subject, setSubject] = useState("");
  const [files, setFiles] = useState([]);
  const [status, setStatus] = useState("IDLE");
  const [error, setError] = useState("");
  const pollingRef = useRef(null);

  useEffect(() => {
    return () => clearInterval(pollingRef.current);
  }, []);

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setFiles((prev) => [...prev, ...Array.from(e.target.files)]);
      setError("");
      e.target.value = ""; 
    }
  };

  const removeFile = (index) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const startAnalysis = async () => {
    if (!subject.trim()) return setError("Please enter a Subject name.");
    if (files.length < 2) return setError("Please upload at least 2 files to compare.");

    setStatus("UPLOADING");
    setError("");

    try {
      const session = await createSession({ subject, title: "Auto Analysis" });
      await uploadFiles(session.session_id, files);
      await triggerAutoProcess(session.session_id);

      setStatus("PROCESSING");
      
      pollingRef.current = setInterval(async () => {
        try {
          const statusRes = await checkSessionStatus(session.session_id);
          if (statusRes.status === "COMPLETED") {
            clearInterval(pollingRef.current);
            setStatus("COMPLETED");
            // UPDATE: Redirect to dynamic URL
            setTimeout(() => navigate(`/session/${session.session_id}`), 1500);
          } else if (statusRes.status === "FAILED") {
            clearInterval(pollingRef.current);
            setError("Analysis failed on the server.");
            setStatus("IDLE");
          }
        } catch (err) {
          console.error("Polling error", err);
        }
      }, 2000);

    } catch (err) {
      console.error(err);
      setError(err.message || "Something went wrong.");
      setStatus("IDLE");
    }
  };

  if (status === "PROCESSING" || status === "UPLOADING") {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
        <div className="bg-white p-10 rounded-2xl shadow-lg border max-w-md w-full">
          <Loader2 className="w-16 h-16 text-indigo-600 animate-spin mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">
            {status === "UPLOADING" ? "Uploading..." : "Analyzing..."}
          </h2>
          <p className="text-gray-500">Please wait while we process your documents.</p>
        </div>
      </div>
    );
  }

  if (status === "COMPLETED") {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
        <div className="bg-white p-10 rounded-2xl shadow-lg border border-green-100 max-w-md w-full">
          <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Analysis Complete!</h2>
          <p className="text-gray-500 mb-6">Redirecting to results...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">New Analysis</h1>
        <p className="text-gray-500 mt-2">Upload student assignments to detect plagiarism.</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 space-y-8">
        {error && (
          <div className="bg-red-50 text-red-700 p-4 rounded-lg flex items-center gap-3">
            <AlertCircle className="w-5 h-5" />
            <span className="font-medium">{error}</span>
          </div>
        )}

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Subject Title</label>
          <input type="text" placeholder="e.g. History Final" className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 outline-none" value={subject} onChange={(e) => setSubject(e.target.value)} />
        </div>

        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-2">Upload Documents</label>
          <div className="border-2 border-dashed border-gray-300 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors relative">
            <input type="file" multiple accept=".pdf,.docx,.txt,.jpg,.png" onChange={handleFileChange} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <UploadIcon className="w-8 h-8 text-indigo-600 mb-4" />
              <p className="text-lg font-medium text-gray-900">Click or Drag & Drop</p>
              <p className="text-sm text-gray-500">PDF, DOCX, Images</p>
            </div>
          </div>
        </div>

        {files.length > 0 && (
          <div className="bg-gray-50 rounded-lg p-4 max-h-60 overflow-y-auto space-y-2">
            {files.map((file, idx) => (
              <div key={idx} className="flex items-center justify-between bg-white p-3 rounded-md border border-gray-200">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-gray-400" />
                  <span className="text-sm text-gray-700 truncate max-w-xs">{file.name}</span>
                </div>
                <button onClick={() => removeFile(idx)}><X className="w-5 h-5 text-gray-400 hover:text-red-500" /></button>
              </div>
            ))}
          </div>
        )}

        <div className="pt-4 border-t">
          <button onClick={startAnalysis} disabled={files.length < 2 || !subject} className="w-full py-4 rounded-xl text-white font-semibold text-lg bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed shadow-md transition-all">
            Analyze Documents
          </button>
        </div>
      </div>
    </div>
  );
}