const RecentAnalyses = () => {
  const data = [
    { title: "Assignment 1 - AI Fundamentals", date: "2026-01-30", submissions: 45, alerts: 3 },
    { title: "Essay - Machine Learning", date: "2026-01-28", submissions: 38, alerts: 5 },
    { title: "Lab Report - Data Science", date: "2026-01-25", submissions: 42, alerts: 2 },
  ];

  return (
    <div className="bg-white rounded-xl p-6 shadow-sm">
      <div className="flex justify-between mb-4">
        <h3 className="font-semibold text-lg">Recent Analyses</h3>
        <button className="text-blue-600 text-sm">View All</button>
      </div>

      <div className="space-y-4">
        {data.map((item, i) => (
          <div key={i} className="flex justify-between items-center border rounded-lg p-4">
            <div>
              <p className="font-medium">{item.title}</p>
              <p className="text-sm text-gray-500">
                {item.date} • {item.submissions} submissions
              </p>
            </div>
            <span className="bg-red-100 text-red-600 text-xs px-3 py-1 rounded-full">
              {item.alerts} alerts
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RecentAnalyses;
