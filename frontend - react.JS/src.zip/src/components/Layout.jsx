import Sidebar from "./Sidebar";
import { Outlet } from "react-router-dom";

export default function Layout() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Sidebar is defined ONCE here */}
      <Sidebar />

      {/* Pages will render inside this div */}
      <div className="flex-1 p-8 overflow-y-auto h-screen ml-64">
        <Outlet />
      </div>
    </div>
  );
}