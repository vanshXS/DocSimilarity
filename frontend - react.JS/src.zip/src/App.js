import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Upload from "./pages/Upload";
import Results from "./pages/Results"; // We will update this file next
import DetailedComparison from "./pages/DetailedComparison";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Dashboard />} />
          <Route path="/upload" element={<Upload />} />
          
          {/* CHANGE: Now accepts a dynamic ID */}
          <Route path="/session/:sessionId" element={<Results />} />
          
          <Route path="/comparison/:id" element={<DetailedComparison />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;